from flask import render_template, request, redirect
from flask_app.models.user import Users
from flask_app import app

@app.route("/")
def index():
    return redirect('/userlist')

@app.route('/userlist')
def userlist():
    uservar=Users.get_all()
    return render_template('readall.html',users=uservar)

@app.route('/user/new')
def new():
    return render_template("create.html")

@app.route('/user/create',methods=['POST'])
def create():
    print(request.form)
    Users.save(request.form)
    return redirect('/userlist')

@app.route('/user/edit/<int:id>')
def edit(id):
    data={'id':id}
    return render_template('edit.html',user=Users.yoink_user(data))

@app.route('/user/update',methods=['POST'])
def update():
    Users.update(request.form)
    return redirect('/userlist')

@app.route('/user/delete/<int:id>')
def delete(id):
    data={'id':id}
    Users.delete(data)
    return redirect('/userlist')

@app.route('/user/show/<int:id>')
def show(id):
    data={'id':id}
    return render_template('readone.html',user=Users.yoink_user(data))